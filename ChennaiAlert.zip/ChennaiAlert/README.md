# Chennai Alert (experimental)

Native Android app (Kotlin, Jetpack Compose) that gives hyperlocal **early advisories** for 12 Chennai
areas and shows official alerts alongside them. English and Tamil.

## Status: NOT yet compiled or run
The code was written without an Android SDK available, so it has never been built. Expect to fix a
few compile errors on first sync. XML resources were validated and English/Tamil strings match.

## Open and run
1. Install Android Studio (Ladybug or newer) with JDK 17.
2. File > Open > this folder. Let Gradle sync (Studio will offer to create the Gradle wrapper;
   AGP 8.7.2 needs Gradle 8.9+).
3. Run on a device/emulator (Android 8.0+, API 26). Run unit tests: `./gradlew test`.

## What it does
| Feature | Source | Notes |
|---|---|---|
| Hourly rain (past 3 h, next 12 h) per area | Open-Meteo | Free tier is **non-commercial only**; a commercial app needs a paid key |
| Rain risk advisory (Watch / Warning / Severe) | `RiskEngine.rain` | Heuristic thresholds, **uncalibrated**; flood-prone areas use 0.7x thresholds; heavy rain in the last 3 h bumps the level |
| Earthquakes (24 h) near Chennai, plus M7+ regional | USGS | Reported *after* the event, not earlier than government |
| Official alerts filtered to Tamil Nadu/Chennai | NDMA SACHET | **Endpoint and field names unverified**, see below |
| Background checks every ~15 min + notifications for Warning+ | WorkManager | 15 min is Android's minimum; Doze may delay it |

## Things you must do before real users rely on it
1. **Verify the SACHET feed.** Confirm the real public CAP/RSS endpoint and terms with NDMA/C-DOT, then
   edit `SachetSource` in `data/Sources.kt`. Failures show in the UI as "could not be loaded".
2. **Back-test and calibrate the rain thresholds** against past Chennai floods (2015, Dec 2023 Michaung)
   using IMD/Chennai Corporation rain-gauge data. Right now they are educated guesses.
3. **Get better data than a 9-11 km global model:** IMD Chennai radar, Chennai Corporation / TN rain gauges,
   river and reservoir levels (Adyar, Cooum, Chembarambakkam). This is where you can genuinely beat
   district-level government warnings.
4. **Server-side push (FCM)** if you need alerts faster than 15-minute polling or reliable delivery in Doze.
5. **Have a native Tamil speaker review** the Tamil strings.
6. Consider legal positioning: label everything as unofficial (already done) and link to IMD/TNSDMA.
   Call 112 in emergencies.

## Layout
```
app/src/main/java/com/chennaialert/app/
  data/    Models, Sources (Open-Meteo, USGS, SACHET), RiskEngine, Repository
  notify/  Prefs, Notifier, AlertWorker + Scheduler
  ui/      AppScreen (Compose), MainViewModel, Theme
app/src/test/  RiskEngineTest
```
