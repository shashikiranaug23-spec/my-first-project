package com.chennaialert.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope

object Repository {

    /** Fetches all sources in parallel; one failing source never blocks the others. */
    suspend fun load(area: Area): Snapshot = coroutineScope {
        val rainD = async(Dispatchers.IO) { runCatching { OpenMeteo.fetch(area) } }
        val quakeD = async(Dispatchers.IO) { runCatching { Usgs.fetch() } }
        val officialD = async(Dispatchers.IO) { runCatching { SachetSource.fetch() } }

        val rain = rainD.await()
        val quakes = quakeD.await()
        val official = officialD.await()
        val now = System.currentTimeMillis()

        val failed = buildList {
            if (rain.isFailure) add("rain")
            if (quakes.isFailure) add("earthquakes")
            if (official.isFailure) add("official alerts")
        }

        val advisories = buildList {
            rain.getOrNull()?.let { r -> RiskEngine.rain(area, r)?.let { add(it) } }
            addAll(RiskEngine.quakes(quakes.getOrDefault(emptyList()), now))
        }.sortedByDescending { it.level }

        Snapshot(
            rain = rain.getOrNull(),
            quakes = quakes.getOrDefault(emptyList()).sortedByDescending { it.timeMs },
            official = official.getOrDefault(emptyList()),
            advisories = advisories,
            failedSources = failed,
            fetchedAtMs = now,
        )
    }
}
