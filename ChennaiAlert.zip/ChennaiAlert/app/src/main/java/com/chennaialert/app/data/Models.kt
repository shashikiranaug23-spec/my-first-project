package com.chennaialert.app.data

import android.content.Context

data class Area(
    val id: String,
    val nameEn: String,
    val nameTa: String,
    val lat: Double,
    val lon: Double,
    /** Historically waterlogging-prone: warning thresholds are lowered for these. */
    val floodProne: Boolean,
) {
    fun name(tamil: Boolean) = if (tamil) nameTa else nameEn
}

fun isTamil(ctx: Context): Boolean = ctx.resources.configuration.locales[0].language == "ta"

/** Approximate centre points. Replace with ward-level polygons / sensor sites later. */
object Areas {
    const val CHENNAI_LAT = 13.0827
    const val CHENNAI_LON = 80.2707

    val all = listOf(
        Area("velachery", "Velachery", "வேளச்சேரி", 12.9815, 80.2180, true),
        Area("pallikaranai", "Pallikaranai", "பள்ளிக்கரணை", 12.9372, 80.2132, true),
        Area("madipakkam", "Madipakkam", "மடிப்பாக்கம்", 12.9626, 80.1980, true),
        Area("adyar", "Adyar", "அடையாறு", 13.0012, 80.2565, true),
        Area("tambaram", "Tambaram", "தாம்பரம்", 12.9249, 80.1000, true),
        Area("sholinganallur", "Sholinganallur", "சோழிங்கநல்லூர்", 12.9010, 80.2279, true),
        Area("ennore", "Ennore / North Chennai", "எண்ணூர் / வடசென்னை", 13.2150, 80.3200, true),
        Area("tnagar", "T. Nagar", "தி. நகர்", 13.0418, 80.2341, false),
        Area("kodambakkam", "Kodambakkam", "கோடம்பாக்கம்", 13.0521, 80.2255, false),
        Area("mylapore", "Mylapore", "மயிலாப்பூர்", 13.0368, 80.2676, false),
        Area("annanagar", "Anna Nagar", "அண்ணா நகர்", 13.0850, 80.2101, false),
        Area("perambur", "Perambur", "பெரம்பூர்", 13.1186, 80.2330, false),
    )

    fun byId(id: String?): Area = all.firstOrNull { it.id == id } ?: all.first()
}

data class RainPoint(val epochSec: Long, val mm: Double)

data class RainData(val past: List<RainPoint>, val future: List<RainPoint>)

data class Quake(
    val id: String,
    val place: String,
    val mag: Double,
    val timeMs: Long,
    val distKm: Double,
    val depthKm: Double,
)

data class OfficialAlert(val id: String, val title: String, val detail: String)

enum class Level { NONE, WATCH, WARNING, SEVERE }

/**
 * Text is stored as string-resource ids plus args so it can be rendered in English or Tamil,
 * both in the UI and in background notifications. An [Area] in the args is replaced by its
 * localized name at format time.
 */
data class Advisory(
    val id: String,
    val level: Level,
    val titleRes: Int,
    val titleArgs: List<Any>,
    val detailRes: Int,
    val detailArgs: List<Any>,
) {
    fun title(ctx: Context): String = format(ctx, titleRes, titleArgs)
    fun detail(ctx: Context): String = format(ctx, detailRes, detailArgs)

    private fun format(ctx: Context, res: Int, args: List<Any>): String {
        val tamil = isTamil(ctx)
        val resolved = args.map { if (it is Area) it.name(tamil) else it }
        return ctx.getString(res, *resolved.toTypedArray())
    }
}

data class Snapshot(
    val rain: RainData?,
    val quakes: List<Quake>,
    val official: List<OfficialAlert>,
    val advisories: List<Advisory>,
    val failedSources: List<String>,
    val fetchedAtMs: Long,
)
