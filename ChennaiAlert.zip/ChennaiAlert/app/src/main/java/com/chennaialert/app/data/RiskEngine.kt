package com.chennaialert.app.data

import com.chennaialert.app.R

/**
 * Rule-based advisory engine.
 *
 * The rain thresholds are heuristics loosely modelled on IMD's rainfall categories (heavy
 * 64.5-115.5 mm/day, very heavy 115.6-204.4 mm/day) compressed into shorter windows, with
 * lower thresholds for waterlogging-prone areas. They are NOT calibrated. Before relying on
 * them, back-test against past Chennai events (e.g. Nov-Dec 2015, Dec 2023 Michaung).
 */
object RiskEngine {

    fun rain(area: Area, rain: RainData): Advisory? {
        val f = rain.future.map { it.mm }
        if (f.isEmpty()) return null

        val max1h = f.take(6).maxOrNull() ?: 0.0
        val sum3 = f.take(3).sum()
        val sum12 = f.take(12).sum()
        val past3 = rain.past.takeLast(3).sumOf { it.mm }

        val s = if (area.floodProne) 0.7 else 1.0
        var level = when {
            max1h >= 40 * s || sum3 >= 100 * s || sum12 >= 200 * s -> Level.SEVERE
            max1h >= 25 * s || sum3 >= 65 * s || sum12 >= 115 * s -> Level.WARNING
            max1h >= 12 * s || sum3 >= 35 * s || sum12 >= 65 * s -> Level.WATCH
            else -> Level.NONE
        }
        if (level == Level.NONE) return null

        // Already-wet ground drains worse: bump one level if heavy rain just fell.
        if (past3 >= 30 && level != Level.SEVERE) level = Level.values()[level.ordinal + 1]

        return Advisory(
            id = "rain-${area.id}-$level",
            level = level,
            titleRes = R.string.rain_title,
            titleArgs = listOf(area),
            detailRes = R.string.rain_detail,
            detailArgs = listOf(max1h, sum3, sum12, past3),
        )
    }

    fun quakes(quakes: List<Quake>, nowMs: Long): List<Advisory> {
        val out = ArrayList<Advisory>()
        for (q in quakes) {
            val ageH = (nowMs - q.timeMs) / 3_600_000.0
            val local = when {
                q.distKm <= 300 && q.mag >= 5.0 -> Level.WARNING
                q.distKm <= 1000 && q.mag >= 6.0 -> Level.WARNING
                q.distKm <= 300 && q.mag >= 4.0 -> Level.WATCH
                else -> Level.NONE
            }
            if (local != Level.NONE && ageH <= 6) {
                out.add(
                    Advisory(
                        id = "quake-${q.id}",
                        level = local,
                        titleRes = R.string.quake_local_title,
                        titleArgs = listOf(q.mag),
                        detailRes = R.string.quake_local_detail,
                        detailArgs = listOf(q.place, q.distKm, q.depthKm),
                    ),
                )
            } else if (q.mag >= 7.0 && q.distKm <= 3500 && ageH <= 3) {
                out.add(
                    Advisory(
                        id = "regional-${q.id}",
                        level = Level.WARNING,
                        titleRes = R.string.tsunami_title,
                        titleArgs = listOf(q.mag),
                        detailRes = R.string.tsunami_detail,
                        detailArgs = listOf(q.place, q.distKm),
                    ),
                )
            }
        }
        return out
    }
}
