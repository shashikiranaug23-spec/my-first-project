package com.chennaialert.app.data

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

internal object Http {
    fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000
        c.readTimeout = 15_000
        c.setRequestProperty("User-Agent", "ChennaiAlert/0.1 (experimental)")
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }
}

fun haversineKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
    val r = 6371.0
    val dLat = Math.toRadians(lat2 - lat1)
    val dLon = Math.toRadians(lon2 - lon1)
    val a = sin(dLat / 2).pow(2) +
        cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2).pow(2)
    return 2 * r * asin(sqrt(a))
}

/**
 * Hourly precipitation from Open-Meteo (past 3 h + next 12 h).
 * NOTE: Open-Meteo's free API is for non-commercial use; a commercial app needs a paid key.
 */
object OpenMeteo {
    fun fetch(area: Area): RainData {
        val url = "https://api.open-meteo.com/v1/forecast" +
            "?latitude=${area.lat}&longitude=${area.lon}" +
            "&hourly=precipitation&past_hours=3&forecast_hours=12&timeformat=unixtime"
        val hourly = JSONObject(Http.get(url)).getJSONObject("hourly")
        val times = hourly.getJSONArray("time")
        val precip = hourly.getJSONArray("precipitation")
        val nowSec = System.currentTimeMillis() / 1000
        val past = ArrayList<RainPoint>()
        val future = ArrayList<RainPoint>()
        for (i in 0 until times.length()) {
            val t = times.getLong(i)
            val p = RainPoint(t, precip.optDouble(i, 0.0))
            if (t <= nowSec) past.add(p) else future.add(p)
        }
        return RainData(past, future)
    }
}

/** Earthquakes from the USGS FDSN feed, last 24 h, centred on Chennai. */
object Usgs {
    private const val LOCAL_RADIUS_KM = 500.0
    private const val REGIONAL_MIN_MAG = 6.5

    fun fetch(): List<Quake> {
        val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US)
        fmt.timeZone = TimeZone.getTimeZone("UTC")
        val start = fmt.format(System.currentTimeMillis() - 24L * 3600 * 1000)
        val url = "https://earthquake.usgs.gov/fdsnws/event/1/query?format=geojson" +
            "&latitude=${Areas.CHENNAI_LAT}&longitude=${Areas.CHENNAI_LON}" +
            "&maxradiuskm=4000&minmagnitude=4&orderby=time&limit=200&starttime=$start"
        val features = JSONObject(Http.get(url)).optJSONArray("features") ?: JSONArray()
        val out = ArrayList<Quake>()
        for (i in 0 until features.length()) {
            val f = features.getJSONObject(i)
            val props = f.getJSONObject("properties")
            val coords = f.getJSONObject("geometry").getJSONArray("coordinates")
            val mag = props.optDouble("mag", Double.NaN)
            if (mag.isNaN()) continue
            val dist = haversineKm(
                Areas.CHENNAI_LAT, Areas.CHENNAI_LON,
                coords.getDouble(1), coords.getDouble(0),
            )
            if (dist <= LOCAL_RADIUS_KM || mag >= REGIONAL_MIN_MAG) {
                out.add(
                    Quake(
                        id = f.optString("id", "q$i"),
                        place = props.optString("place", "Unknown"),
                        mag = mag,
                        timeMs = props.optLong("time", 0L),
                        distKm = dist,
                        depthKm = coords.optDouble(2, 0.0),
                    ),
                )
            }
        }
        return out
    }
}

/**
 * Official alerts from NDMA's SACHET portal (CAP feed).
 *
 * IMPORTANT: the endpoint below and the JSON field names are NOT verified against the live
 * service. Confirm the real public CAP/RSS endpoint (and terms of use) with NDMA/C-DOT, then
 * adjust URL and key lists. The parser is deliberately lenient and keeps only items that
 * mention Tamil Nadu or Chennai; any failure is reported in the UI rather than hidden.
 */
object SachetSource {
    const val URL = "https://sachet.ndma.gov.in/cap_public_website/FetchAllAlertDetails"

    private val TITLE_KEYS = listOf("warning_message", "headline", "event", "disaster_type", "title")
    private val DETAIL_KEYS = listOf("area_description", "description", "severity", "instruction")

    fun fetch(): List<OfficialAlert> {
        val text = Http.get(URL).trim()
        val arr: JSONArray = if (text.startsWith("[")) {
            JSONArray(text)
        } else {
            val o = JSONObject(text)
            o.optJSONArray("alerts") ?: o.optJSONArray("data") ?: JSONArray()
        }
        val out = ArrayList<OfficialAlert>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val blob = o.toString().lowercase(Locale.ROOT)
            if (!blob.contains("tamil nadu") && !blob.contains("chennai")) continue
            out.add(
                OfficialAlert(
                    id = blob.hashCode().toString(),
                    title = pick(o, TITLE_KEYS).ifBlank { "Official alert" },
                    detail = DETAIL_KEYS.mapNotNull { k -> o.optString(k).takeIf { it.isNotBlank() } }
                        .joinToString(" · "),
                ),
            )
        }
        return out
    }

    private fun pick(o: JSONObject, keys: List<String>): String =
        keys.firstNotNullOfOrNull { k -> o.optString(k).takeIf { it.isNotBlank() } } ?: ""
}
