package com.chennaialert.app.notify

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.chennaialert.app.data.Areas
import com.chennaialert.app.data.Level
import com.chennaialert.app.data.Repository
import java.util.concurrent.TimeUnit

class AlertWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result {
        val prefs = Prefs(applicationContext)
        if (!prefs.notificationsOn) return Result.success()
        return try {
            val snap = Repository.load(Areas.byId(prefs.areaId))
            val now = System.currentTimeMillis()
            snap.advisories
                .filter { it.level >= Level.WARNING }
                .filter { prefs.claimNotification(it.id, now) }
                .forEach {
                    Notifier.show(
                        applicationContext,
                        it.id.hashCode(),
                        it.title(applicationContext),
                        it.detail(applicationContext),
                    )
                }
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}

object Scheduler {
    private const val NAME = "chennai_alert_poll"

    /** WorkManager's minimum period is 15 minutes; Android may delay runs further (Doze). */
    fun enable(ctx: Context) {
        val req = PeriodicWorkRequestBuilder<AlertWorker>(15, TimeUnit.MINUTES)
            .setConstraints(
                Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build(),
            )
            .build()
        WorkManager.getInstance(ctx.applicationContext)
            .enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.KEEP, req)
    }

    fun disable(ctx: Context) {
        WorkManager.getInstance(ctx.applicationContext).cancelUniqueWork(NAME)
    }
}
