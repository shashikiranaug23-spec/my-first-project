package com.chennaialert.app.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.chennaialert.app.data.Area
import com.chennaialert.app.data.Repository
import com.chennaialert.app.data.Snapshot
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class UiState(val loading: Boolean = true, val snapshot: Snapshot? = null)

class MainViewModel : ViewModel() {
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()
    private var job: Job? = null

    fun refresh(area: Area) {
        job?.cancel()
        job = viewModelScope.launch {
            _state.update { it.copy(loading = true) }
            val snap = Repository.load(area)
            _state.value = UiState(loading = false, snapshot = snap)
        }
    }
}
