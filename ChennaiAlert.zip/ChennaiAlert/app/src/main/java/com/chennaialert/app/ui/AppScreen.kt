package com.chennaialert.app.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.chennaialert.app.R
import com.chennaialert.app.data.Advisory
import com.chennaialert.app.data.Areas
import com.chennaialert.app.data.Level
import com.chennaialert.app.data.Quake
import com.chennaialert.app.data.RainData
import com.chennaialert.app.data.isTamil
import com.chennaialert.app.notify.Notifier
import com.chennaialert.app.notify.Prefs
import com.chennaialert.app.notify.Scheduler
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.max
import kotlin.math.min

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppScreen(vm: MainViewModel = viewModel()) {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    var areaId by rememberSaveable { mutableStateOf(prefs.areaId) }
    var notify by remember { mutableStateOf(prefs.notificationsOn && Notifier.hasPermission(ctx)) }
    val state by vm.state.collectAsState()
    val area = Areas.byId(areaId)
    val tamil = isTamil(ctx)

    LaunchedEffect(areaId) { vm.refresh(area) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { granted ->
        if (granted) {
            prefs.notificationsOn = true
            notify = true
            Scheduler.enable(ctx)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(stringResource(R.string.app_name))
                        Text(stringResource(R.string.subtitle), style = MaterialTheme.typography.labelSmall)
                    }
                },
                actions = {
                    TextButton(onClick = { vm.refresh(area) }) { Text(stringResource(R.string.refresh)) }
                },
            )
        },
    ) { pad ->
        LazyColumn(
            modifier = Modifier.padding(pad).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Column {
                    Text(stringResource(R.string.choose_area), style = MaterialTheme.typography.titleSmall)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(Areas.all) { a ->
                            FilterChip(
                                selected = a.id == areaId,
                                onClick = {
                                    areaId = a.id
                                    prefs.areaId = a.id
                                },
                                label = { Text(a.name(tamil)) },
                            )
                        }
                    }
                }
            }

            val snap = state.snapshot
            if (state.loading && snap == null) {
                item { Text(stringResource(R.string.loading)) }
            }

            if (snap != null) {
                item {
                    Text(stringResource(R.string.advisories), style = MaterialTheme.typography.titleMedium)
                }
                if (snap.advisories.isEmpty()) {
                    item { Text(stringResource(R.string.no_advisories)) }
                } else {
                    items(snap.advisories, key = { it.id }) { AdvisoryCard(it) }
                }

                snap.rain?.let { rain ->
                    item { RainSection(rain) }
                }

                item {
                    Text(stringResource(R.string.quakes_title), style = MaterialTheme.typography.titleMedium)
                }
                if (snap.quakes.isEmpty()) {
                    item { Text(stringResource(R.string.no_quakes)) }
                } else {
                    items(snap.quakes.take(8)) { QuakeRow(it) }
                }

                item {
                    Text(stringResource(R.string.official_title), style = MaterialTheme.typography.titleMedium)
                }
                if (snap.official.isEmpty()) {
                    item { Text(stringResource(R.string.no_official)) }
                } else {
                    items(snap.official.take(10)) { a ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp)) {
                                Text(a.title, fontWeight = FontWeight.SemiBold)
                                if (a.detail.isNotBlank()) Text(a.detail, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }

                if (snap.failedSources.isNotEmpty()) {
                    item {
                        Text(
                            stringResource(R.string.load_error, snap.failedSources.joinToString()),
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
                item {
                    Text(
                        stringResource(R.string.updated, formatTime(snap.fetchedAtMs)),
                        style = MaterialTheme.typography.labelSmall,
                    )
                }
            }

            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(stringResource(R.string.notify_toggle), fontWeight = FontWeight.SemiBold)
                        Text(stringResource(R.string.notify_hint), style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(
                        checked = notify,
                        onCheckedChange = { on ->
                            if (!on) {
                                prefs.notificationsOn = false
                                notify = false
                                Scheduler.disable(ctx)
                            } else if (Notifier.hasPermission(ctx)) {
                                prefs.notificationsOn = true
                                notify = true
                                Scheduler.enable(ctx)
                            } else if (Build.VERSION.SDK_INT >= 33) {
                                permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            }
                        },
                    )
                }
            }

            item {
                Column {
                    Text(stringResource(R.string.sources), style = MaterialTheme.typography.labelSmall)
                    Text(
                        stringResource(R.string.disclaimer),
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(top = 4.dp, bottom = 24.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun AdvisoryCard(a: Advisory) {
    val ctx = LocalContext.current
    val (bg, label) = when (a.level) {
        Level.SEVERE -> Color(0xFFFFCDD2) to stringResource(R.string.level_severe)
        Level.WARNING -> Color(0xFFFFE0B2) to stringResource(R.string.level_warning)
        else -> Color(0xFFFFF3CD) to stringResource(R.string.level_watch)
    }
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = bg, contentColor = Color(0xFF1B1B1B)),
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(label.uppercase(), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            Text(a.title(ctx), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Text(a.detail(ctx), style = MaterialTheme.typography.bodyMedium)
            Text(stringResource(R.string.unofficial_badge), style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun RainSection(rain: RainData) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(stringResource(R.string.rain_chart_title), style = MaterialTheme.typography.titleMedium)
        RainChart(rain)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(stringResource(R.string.chart_past), style = MaterialTheme.typography.labelSmall)
            Text(stringResource(R.string.chart_next), style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun RainChart(rain: RainData) {
    val past = rain.past.takeLast(3)
    val all = past + rain.future
    val maxMm = max(5.0, all.maxOfOrNull { it.mm } ?: 0.0)
    val pastColor = MaterialTheme.colorScheme.outline
    val futureColor = MaterialTheme.colorScheme.primary
    val pastCount = min(3, past.size)
    Canvas(Modifier.fillMaxWidth().height(100.dp)) {
        val n = all.size
        if (n == 0) return@Canvas
        val gap = 4.dp.toPx()
        val w = (size.width - gap * (n - 1)) / n
        all.forEachIndexed { i, p ->
            val h = max((p.mm / maxMm).toFloat() * size.height, 2f)
            drawRect(
                color = if (i < pastCount) pastColor else futureColor,
                topLeft = Offset(i * (w + gap), size.height - h),
                size = Size(w, h),
            )
        }
    }
}

@Composable
private fun QuakeRow(q: Quake) {
    Text(
        stringResource(R.string.quake_row, q.mag, q.place, q.distKm, formatTime(q.timeMs)),
        style = MaterialTheme.typography.bodySmall,
    )
}

private fun formatTime(ms: Long): String {
    val f = SimpleDateFormat("dd MMM HH:mm", Locale.getDefault())
    f.timeZone = TimeZone.getTimeZone("Asia/Kolkata")
    return f.format(Date(ms))
}
