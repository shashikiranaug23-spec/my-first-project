package com.chennaialert.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.chennaialert.app.notify.Notifier
import com.chennaialert.app.ui.AppScreen
import com.chennaialert.app.ui.ChennaiAlertTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Notifier.createChannel(this)
        setContent {
            ChennaiAlertTheme {
                AppScreen()
            }
        }
    }
}
