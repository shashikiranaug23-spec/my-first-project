package com.chennaialert.app.notify

import android.content.Context
import com.chennaialert.app.data.Areas

class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("chennai_alert", Context.MODE_PRIVATE)

    var areaId: String
        get() = sp.getString("area", Areas.all.first().id) ?: Areas.all.first().id
        set(v) = sp.edit().putString("area", v).apply()

    var notificationsOn: Boolean
        get() = sp.getBoolean("notify", false)
        set(v) = sp.edit().putBoolean("notify", v).apply()

    /** True if this advisory id has not been notified in the last [windowMs]; records it if so. */
    fun claimNotification(id: String, nowMs: Long, windowMs: Long = 6L * 3600 * 1000): Boolean {
        val kept = HashMap<String, Long>()
        for (entry in sp.getStringSet("sent", emptySet()).orEmpty()) {
            val i = entry.lastIndexOf('|')
            if (i < 0) continue
            val t = entry.substring(i + 1).toLongOrNull() ?: continue
            if (nowMs - t < windowMs) kept[entry.substring(0, i)] = t
        }
        if (kept.containsKey(id)) return false
        kept[id] = nowMs
        sp.edit().putStringSet("sent", kept.map { "${it.key}|${it.value}" }.toSet()).apply()
        return true
    }
}
