package com.chennaialert.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class RiskEngineTest {
    private val velachery = Areas.byId("velachery")   // flood-prone: thresholds x0.7
    private val tnagar = Areas.byId("tnagar")         // normal thresholds

    private fun rain(past: List<Double>, future: List<Double>) = RainData(
        past.mapIndexed { i, mm -> RainPoint(i.toLong(), mm) },
        future.mapIndexed { i, mm -> RainPoint(100L + i, mm) },
    )

    @Test fun dryWeatherGivesNoAdvisory() {
        assertNull(RiskEngine.rain(velachery, rain(listOf(0.0, 0.0, 0.0), List(12) { 0.5 })))
    }

    @Test fun sameRainIsMoreSeriousInFloodProneArea() {
        val r = rain(listOf(0.0, 0.0, 0.0), listOf(20.0, 20.0, 0.0) + List(9) { 0.0 }) // 40 mm / 3 h
        assertNull(RiskEngine.rain(tnagar, r)?.takeIf { it.level > Level.WATCH })
        assertEquals(Level.WATCH, RiskEngine.rain(tnagar, r)?.level)
        assertNotNull(RiskEngine.rain(velachery, r))
    }

    @Test fun wetGroundBumpsLevel() {
        val future = listOf(14.0) + List(11) { 0.0 }   // 1 h burst -> WATCH in T. Nagar
        val dry = RiskEngine.rain(tnagar, rain(listOf(0.0, 0.0, 0.0), future))!!
        val wet = RiskEngine.rain(tnagar, rain(listOf(15.0, 15.0, 5.0), future))!!
        assertEquals(Level.WATCH, dry.level)
        assertEquals(Level.WARNING, wet.level)
    }

    @Test fun distantSmallQuakeIgnoredButLargeNearbyWarns() {
        val now = 10_000_000L
        val small = Quake("a", "far", 4.2, now - 1000, 450.0, 10.0)
        val big = Quake("b", "near", 5.3, now - 1000, 200.0, 10.0)
        assertEquals(0, RiskEngine.quakes(listOf(small), now).size)
        assertEquals(Level.WARNING, RiskEngine.quakes(listOf(big), now).single().level)
    }
}
